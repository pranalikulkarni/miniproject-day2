package com.cg.asset.dto;

import java.util.Date;

public class Asset {
	
	private int AllocationId;
	private int AssetId;
	private int EmpNo;
	private Date AllocationDate;
	private Date ReleaseDate;
	private String AssetName;
	private String AssetDes;
	private int Quantity;
	private String Status;
	
	
	


	public Asset(int allocationId, int assetId, int empNo) {
		super();
		AllocationId = allocationId;
		AssetId = assetId;
		EmpNo = empNo;
	}


	public int getAllocationId() {
		return AllocationId;
	}

	public void setAllocationId(int allocationId) {
		AllocationId = allocationId;
	}

	public Asset(int allocationId, int assetId, int empNo, Date allocationDate,
			Date releaseDate, String assetName, String assetDes, int quantity,
			String status) {
		super();
		AllocationId = allocationId;
		AssetId = assetId;
		EmpNo = empNo;
		AllocationDate = allocationDate;
		ReleaseDate = releaseDate;
		AssetName = assetName;
		AssetDes = assetDes;
		Quantity = quantity;
		Status = status;
	}


	public int getAssetId() {
		return AssetId;
	}

	public void setAssetId(int assetId) {
		AssetId = assetId;
	}

	public int getEmpNo() {
		return EmpNo;
	}

	public void setEmpNo(int empNo) {
		EmpNo = empNo;
	}

	public Date getAllocationDate() {
		return AllocationDate;
	}

	public void setAllocationDate(Date allocationDate) {
		AllocationDate = allocationDate;
	}

	public Date getReleaseDate() {
		return ReleaseDate;
	}

	public void setReleaseDate(Date releaseDate) {
		ReleaseDate = releaseDate;
	}

	public String getAssetName() {
		return AssetName;
	}

	public void setAssetName(String assetName) {
		AssetName = assetName;
	}

	public String getAssetDes() {
		return AssetDes;
	}

	public void setAssetDes(String assetDes) {
		AssetDes = assetDes;
	}

	public int getQuantity() {
		return Quantity;
	}

	public void setQuantity(int quantity) {
		Quantity = quantity;
	}

	public String getStatus() {
		return Status;
	}

	public void setStatus(String status) {
		Status = status;
	}
	

}
