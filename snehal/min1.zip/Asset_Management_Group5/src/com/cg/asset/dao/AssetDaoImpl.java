package com.cg.asset.dao;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Date;

import com.cg.asset.dbutil.DbUtil;
import com.cg.asset.dto.Asset;
import com.cg.asset.exception.AssetException;



public  class AssetDaoImpl {
	Connection conn = null;
	
	public ArrayList<Asset> raiseRequest(Asset bean) throws AssetException
	{ArrayList<Asset> request=new ArrayList<Asset>();
		try {
			
			conn=DbUtil.getConnections();
		
		String sql="SELECT assetId,allocId,empNo FROM Asset s JOIN Asset_Allocation l ON s.Assetid = l.Assetid WHERE AssetName = ?";
		PreparedStatement str=conn.prepareStatement(sql);
		str.setString(1,bean.getAssetName());
		ResultSet rs=str.executeQuery();
		while(rs.next())
		{
			
			int assetId=rs.getInt(1);
			int allocId=rs.getInt(2); 
			int empNo=rs.getInt(3);
			request.add(new Asset(assetId,allocId,empNo));
			
		}
		}catch(IOException | SQLException e)
		{
			throw new AssetException("Could not retrieve");
			
		}
		return request;
	}
	public int insertRequests(Asset bean) throws AssetException
	{
	
       int row=0;
		try {
	
			conn=DbUtil.getConnections();
			String query="insert into asset_allocation values(?,?,?)";
			PreparedStatement str=conn.prepareStatement(query);
			str.setInt(1,bean.getAllocationId());
			str.setInt(2,bean.getAssetId());
			str.setInt(3,bean.getEmpNo());
			
			row= str.executeUpdate();
		
		}catch(IOException | SQLException e)
		{
			throw new AssetException("Could not retrieve");
			
		}	
		
		return row;
			
	}
	
		
		public int approveRequest() throws AssetException
		{
		
			int row=0;
			try{
			conn=DbUtil.getConnections();
			String query="update asset_allocation set Allocation_date=sysdate and release_date=sysdate+10";
			PreparedStatement ps=conn.prepareStatement(query);
			row=ps.executeUpdate();
			}
			catch(IOException | SQLException e)
			{
				throw new AssetException("Could not update");
				
			}
		
			return row;
			
			
		}
		public int rejectRequest(int id) throws AssetException
		{
			int row=0;
			try{
			conn=DbUtil.getConnections();
			String query="delete from asset_allocation where Allocation_id=?";
			PreparedStatement ps=conn.prepareStatement(query);
			
			ps.setInt(1,id);
			
			row=ps.executeUpdate();
			}catch(IOException | SQLException e)
			{
				throw new AssetException("Could not delete the request");
				
			}
		
			return row;
			
		}
		
		
		
		public ArrayList<Asset> retrieveDetails(int id) throws AssetException {
			
			ArrayList<Asset> list = new ArrayList<Asset>();
			try {
				Connection conn = DbUtil.getConnections();
				
			
			String sql = "SELECT * FROM Asset s JOIN Asset_Allocation l ON s.Assetid = l.Assetid WHERE AllocationId = ?";;
			
			PreparedStatement pst = conn.prepareStatement(sql);
	        pst.setInt(1, id);
	      
			ResultSet rs = pst.executeQuery();
			
			
			
			
			while(rs.next())
			{
				
				
				int AssetId = rs.getInt(1);
				String AssetName = rs.getString(2);
				String AssetDes = rs.getString(3);
				int Quantity = rs.getInt(4);
				String Status =rs.getString(5);
				int AllocationId= rs.getInt(6);
				int EmpNo  = rs.getInt(8);
				Date AllocationDate = rs.getDate(9);
				Date ReleaseDate = rs.getDate(10);
				
				
				
				list.add(new Asset(AllocationId,AssetId,EmpNo,AllocationDate,ReleaseDate,AssetName,AssetDes,Quantity,Status));
				
			}
			
			}
			
			catch (IOException | SQLException e) {
				throw new AssetException("Could not view status");
				
			}
			
			return list;
		}
		

	}





