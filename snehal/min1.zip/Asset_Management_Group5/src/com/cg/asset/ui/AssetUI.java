package com.cg.asset.ui;

public class AssetUI {
	
	

}
